Moodle-Log-report-Plugin
========================

Moodle Log report plugin Version 0.0.1

This plugin will generate reports from the log data present in MDL_LOG table in moodle database. Still this plugin is under development.